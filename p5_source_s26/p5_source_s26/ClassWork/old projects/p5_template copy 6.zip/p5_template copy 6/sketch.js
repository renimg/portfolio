let col1 = color(0,0,0,0);
let col2 = color(0,0,0,255);
let col3 = color(255,255,255,255);
let col4 = color(217,87,99,255);
let col5 = color(215,123,186,255);
let col6 = color(69,40,60,255);
let col7 = color(33,27,32,255);
let col8 = color(118,66,138,255);
let col9 = color(34,30,63,255);
let col10 = color(63,63,116,255);
let col11 = color(48,52,109,255);
let col12 = color(91,110,225,255);
let col13 = color(99,155,255,255);
let col14 = color(48,96,130,255);
let col15 = color(55,148,110,255);
let col16 = color(106,190,48,255);
let col17 = color(75,105,47,255);
let col18 = color(251,242,54,255);
let col19 = color(217,160,102,255);
let col20 = color(238,195,154,255);
let col21 = color(223,113,38,255);
let col22 = color(143,86,59,255);
let col23 = color(129,10,0,255);
let col24 = color(172,50,50,255);

let gridarr = [
	[
	col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1
	],
	[
	col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1
	],
	[
	col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1
	],
	[
	col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col2,col2,col2,col1,col1,col1,col1,col1
	],
	[
	col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col2,col23,col24,col2,col2,col2,col2,col1,col1
	],
	[
	col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col2,col2,col2,col23,col24,col2,col2,col24,col23,col2,col1
	],
	[
	col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col2,col23,col24,col23,col2,col2,col2,col23,col24,col2,col2,col2
	],
	[
	col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col2,col2,col23,col24,col24,col2,col23,col24,col23,col23,col24,col24,col24,col2
	],
	[
	col2,col2,col2,col2,col2,col2,col2,col2,col2,col2,col2,col6,col6,col23,col23,col23,col23,col6,col2,col2,col2,col2,col2,col2,col2,col2,col2,col23,col23,col23,col24,col2,col24,col24,col24,col23,col23,col23,col24,col24,col2
	],
	[
	col2,col11,col11,col11,col24,col24,col24,col24,col4,col23,col23,col23,col23,col6,col6,col23,col23,col23,col23,col23,col23,col23,col23,col23,col23,col23,col23,col23,col23,col23,col23,col23,col24,col23,col23,col2,col24,col24,col24,col2,col1
	],
	[
	col2,col11,col9,col9,col9,col9,col23,col23,col4,col24,col24,col24,col4,col4,col24,col24,col3,col3,col24,col24,col24,col24,col23,col23,col24,col23,col23,col23,col24,col24,col24,col24,col24,col23,col2,col2,col23,col23,col2,col1,col1
	],
	[
	col2,col11,col9,col9,col9,col9,col9,col23,col4,col24,col4,col4,col4,col24,col24,col3,col12,col12,col3,col24,col24,col23,col23,col24,col24,col23,col23,col24,col4,col24,col23,col6,col20,col20,col9,col2,col2,col2,col1,col1,col1
	],
	[
	col2,col23,col7,col7,col7,col9,col9,col11,col4,col24,col4,col24,col24,col24,col24,col3,col12,col12,col3,col24,col23,col23,col24,col24,col24,col23,col24,col4,col24,col23,col2,col3,col3,col9,col9,col2,col1,col2,col2,col2,col1
	],
	[
	col2,col23,col9,col9,col9,col9,col9,col11,col4,col4,col4,col24,col3,col3,col24,col24,col3,col3,col24,col24,col23,col24,col4,col23,col24,col24,col4,col20,col3,col3,col2,col6,col24,col9,col11,col2,col2,col23,col24,col24,col2
	],
	[
	col2,col23,col7,col7,col7,col9,col9,col11,col4,col4,col24,col3,col12,col12,col3,col24,col24,col24,col24,col23,col23,col3,col3,col23,col24,col4,col4,col24,col23,col2,col2,col6,col20,col9,col23,col24,col23,col24,col24,col24,col2
	],
	[
	col2,col23,col7,col7,col7,col7,col9,col11,col4,col4,col24,col3,col12,col12,col3,col24,col24,col24,col24,col23,col3,col12,col12,col3,col4,col4,col24,col23,col23,col2,col2,col3,col20,col23,col24,col24,col23,col24,col23,col2,col2
	],
	[
	col2,col23,col7,col7,col7,col7,col9,col11,col4,col4,col24,col24,col3,col3,col24,col24,col24,col24,col24,col23,col3,col12,col12,col3,col4,col24,col20,col20,col3,col3,col2,col6,col24,col23,col24,col23,col2,col23,col24,col24,col2
	],
	[
	col2,col23,col7,col7,col7,col7,col9,col11,col4,col24,col24,col24,col24,col24,col24,col3,col3,col3,col23,col23,col24,col3,col3,col4,col4,col4,col24,col23,col23,col2,col2,col3,col20,col23,col23,col2,col2,col2,col24,col24,col2
	],
	[
	col2,col23,col7,col7,col7,col7,col9,col11,col4,col24,col24,col24,col24,col24,col3,col3,col12,col3,col3,col23,col24,col4,col24,col24,col4,col4,col24,col24,col23,col2,col2,col3,col24,col23,col23,col2,col1,col1,col2,col2,col2
	],
	[
	col2,col23,col7,col7,col7,col7,col9,col11,col4,col24,col24,col24,col24,col24,col3,col12,col12,col12,col3,col23,col24,col4,col24,col24,col24,col4,col24,col20,col3,col3,col2,col6,col24,col9,col11,col2,col1,col1,col1,col1,col1
	],
	[
	col2,col23,col7,col7,col7,col7,col9,col11,col4,col24,col24,col24,col24,col24,col3,col3,col12,col3,col3,col23,col24,col24,col4,col24,col24,col4,col20,col20,col20,col2,col2,col3,col20,col9,col11,col2,col2,col2,col2,col2,col2
	],
	[
	col2,col23,col7,col7,col7,col7,col9,col11,col4,col24,col24,col24,col24,col24,col24,col3,col3,col3,col24,col23,col23,col24,col4,col24,col24,col24,col24,col23,col23,col2,col2,col2,col20,col23,col23,col2,col2,col24,col24,col24,col2
	],
	[
	col2,col23,col7,col7,col7,col7,col9,col11,col4,col24,col24,col24,col24,col24,col24,col24,col24,col24,col24,col24,col23,col24,col24,col4,col24,col24,col24,col24,col3,col3,col2,col2,col24,col23,col23,col23,col23,col23,col24,col24,col2
	],
	[
	col2,col23,col7,col7,col7,col9,col9,col11,col4,col24,col24,col24,col24,col24,col24,col24,col3,col3,col24,col24,col24,col24,col24,col24,col4,col24,col24,col20,col20,col2,col2,col3,col20,col23,col24,col24,col23,col23,col23,col2,col1
	],
	[
	col2,col23,col7,col7,col7,col7,col7,col11,col4,col23,col23,col23,col3,col3,col23,col3,col21,col21,col3,col23,col3,col3,col23,col24,col24,col4,col24,col24,col23,col23,col2,col2,col23,col9,col23,col24,col23,col23,col24,col24,col2
	],
	[
	col2,col23,col7,col9,col9,col9,col9,col11,col4,col23,col23,col3,col4,col4,col3,col3,col21,col22,col3,col3,col5,col8,col3,col24,col24,col24,col4,col24,col24,col20,col3,col3,col20,col9,col11,col2,col2,col2,col24,col24,col2
	],
	[
	col2,col23,col7,col7,col7,col9,col9,col11,col4,col23,col23,col3,col4,col4,col3,col23,col3,col3,col23,col3,col8,col10,col3,col23,col24,col23,col23,col4,col24,col2,col2,col2,col4,col9,col11,col2,col1,col1,col2,col2,col2
	],
	[
	col2,col23,col9,col9,col9,col9,col9,col11,col4,col23,col23,col23,col3,col3,col23,col23,col3,col3,col23,col23,col3,col3,col23,col23,col3,col23,col3,col23,col4,col24,col3,col23,col20,col9,col23,col2,col2,col2,col2,col1,col1
	],
	[
	col2,col23,col7,col7,col7,col9,col9,col23,col24,col23,col23,col3,col3,col23,col23,col3,col13,col12,col3,col23,col23,col23,col23,col7,col7,col7,col7,col7,col23,col4,col24,col3,col4,col23,col23,col23,col23,col24,col24,col2,col1
	],
	[
	col2,col11,col9,col9,col9,col9,col23,col23,col24,col23,col3,col18,col19,col3,col23,col3,col12,col14,col3,col23,col3,col3,col23,col3,col23,col3,col23,col3,col23,col23,col4,col23,col4,col9,col24,col23,col23,col23,col24,col2,col1
	],
	[
	col2,col11,col11,col11,col23,col23,col23,col23,col23,col23,col3,col19,col21,col3,col23,col23,col3,col3,col23,col3,col16,col15,col3,col23,col23,col23,col23,col23,col23,col23,col24,col24,col24,col23,col23,col24,col23,col2,col24,col2,col1
	],
	[
	col2,col2,col2,col2,col2,col2,col2,col2,col2,col2,col2,col3,col3,col23,col23,col23,col6,col6,col6,col3,col15,col17,col3,col2,col2,col2,col2,col2,col6,col23,col23,col23,col2,col2,col2,col23,col24,col23,col2,col1,col1
	],
	[
	col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col2,col3,col3,col2,col1,col1,col1,col1,col1,col2,col23,col23,col2,col23,col24,col24,col2,col24,col24,col2,col1,col1
	],
	[
	col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col2,col1,col1,col1,col1,col1,col1,col1,col2,col6,col23,col23,col23,col23,col24,col2,col2,col2,col2,col1,col1
	],
	[
	col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col2,col23,col23,col2,col2,col24,col2,col1,col1,col1,col1,col1
	],
	[
	col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col2,col2,col1,col2,col23,col2,col1,col1,col1,col1,col1
	],
	[
	col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col2,col2,col2,col1,col1,col1,col1,col1
	],
	[
	col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1
	],
	[
	col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1
	],
	[
	col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1
	],
	[
	col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1,col1
	]]


function setup() {
  createCanvas(1024, 1024);

        for (var i = 0; i < gridarr.length; i++) {
        for (var j = 0; j < gridarr[0].length; j++) {
            fill(arr[i][j] * 128, fade);
            rect(j * 12, i * 12, 10, 10);
        }
    }
}

function draw() {
}