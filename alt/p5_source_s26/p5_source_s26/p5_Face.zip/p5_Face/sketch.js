function setup() {
  createCanvas(1024,1024);
  background(20);
  fill(255);
// frameRate(5);
}

function draw() {
//let ofx = width/2;
//let ofy = height/2;


let objscale;
if (width <= height) 
{
objscale = width/2;
} else {
objscale = height/2;
}

 for (let i = 0; i < 400; i += 20) {
    for (let j = 0; j < 400; j += 20) {
      
      rand = random(255);
      fill(rand,rand,rand);
      rect( i+5, j+5, 10, 10 );
      console.log("this has a greyscale value of" + rand);
    }
  }

//face start
noStroke();
fill(90,81,84);
 triangle(objscale/2,objscale,objscale/2,objscale/3,objscale,objscale/2);
 triangle(objscale*1.5,objscale,objscale*1.5,objscale/3,objscale,objscale/2);
fill(237,163,196);
 triangle(objscale/1.6667,objscale,objscale/1.6667,objscale/2.3077,objscale,objscale/1.6667);
 triangle(objscale*1.4,objscale,objscale*1.4,objscale/2.3077,objscale,objscale/1.6667);
fill(90,81,84);
  circle(objscale,objscale,objscale); //head
rectMode(CENTER);
fill(237,163,196);
  rect(objscale*.9333,objscale*1.2167,objscale*0.1167,objscale*0.1667,0,0,objscale*0.0667,objscale*0.0667);
if ( mouseIsPressed) {
if ( mouseX > objscale *0.84 && mouseX <= objscale *1.008) {
  if ( mouseY > objscale*1.065 && mouseY <= objscale *1.135) {
    fill(237,163,196);
  rect(objscale*.9333,objscale*1.3,objscale*0.1167,objscale*0.1667,0,0,objscale*0.0667,objscale*0.0667);
  }
}

}   // mouse pressed test ends
fill(0);
  ellipse(objscale*0.8833,objscale*1.1333,objscale/3,objscale/5); //mouth
  ellipse(objscale,objscale*1.1333,objscale/3,objscale/5); //mouth
fill(90,81,84);
  ellipse(objscale*0.8833,objscale*1.1167,objscale/3,objscale/5); //mouth
  ellipse(objscale,objscale*1.1167,objscale/3,objscale/5); //mouth
fill(84,64,77);
  circle(objscale*0.7667,objscale*0.9667,objscale/3.75);
  circle(objscale*1.083,objscale*0.9667,objscale/3.75); //eyebags
fill(255);
beginClip();
push();
circle(objscale*0.7667,objscale*0.9333,objscale/3.75);
circle(objscale*1.083,objscale*0.9333,objscale/3.75); //eyes
endClip();
fill(255);
circle(objscale*0.7667,objscale*0.9333,objscale/3.75);
circle(objscale*1.083,objscale*0.9333,objscale/3.75); //eyes
fill(54,89,63);
 ellipse(objscale*0.7667,objscale*0.9333,objscale/7.5,objscale/3.75);
 ellipse(objscale*1.083,objscale*0.9333,objscale/7.5,objscale/3.75); //dark iris
fill(66,115,79);
  ellipse(objscale*0.7667,objscale*0.9333,objscale/10,objscale/4.2857);
  ellipse(objscale*1.083,objscale*0.9333,objscale/10,objscale/4.2857); //dark iris
fill(255);
 ellipse(objscale*0.7667,objscale*0.9333,objscale/15,objscale/5);
 ellipse(objscale*1.083,objscale*0.9333,objscale/15,objscale/5); //dark iris
 pop();
fill(237,163,196);
  ellipse(objscale*0.9167,objscale*1.1,objscale/6,objscale/15); //nose


fill(255);
//circle(400,400,2)

// circle(150,300,2)
// circle(150,100,2)
// circle(300,150,2)

// circle(450,300,2)
// circle(450,100,2)
// circle(300,150,2)

// circle(180,300,2)
// circle(180,130,2)
// circle(300,180,2)

// circle(420,300,2)
// circle(420,130,2)
// circle(300,180,2)
}
